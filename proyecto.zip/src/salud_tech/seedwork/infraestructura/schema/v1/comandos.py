from .mensajes import Mensaje

class ComandoIntegracion(Mensaje):
    ...